﻿using System;
using System.Collections.Generic;

namespace FlowerWorld.Models
{
    public partial class News
    {
        public int ObjId { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
